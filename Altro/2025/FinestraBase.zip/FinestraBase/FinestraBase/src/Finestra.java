import javax.swing.*;
import java.awt.*;

public class Finestra {

    private final int LARGHEZZA_FINESTRA = 400;
    private final int ALTEZZA_FINESTRA = 400;

    public Finestra() {

        //creo il frame
        JFrame frame = new JFrame("Due TextBox + Pulsante");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //creo il pannello che conterrà i componenti grafici
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        //creo i componenti con le dimensioni volute
        JTextField username = new JTextField();
        username.setMaximumSize(new Dimension(LARGHEZZA_FINESTRA - 40, 20));
        JTextField password = new JTextField();
        password.setMaximumSize(new Dimension(LARGHEZZA_FINESTRA - 40, 20));

        //aggiungo i componenti al pannello
        panel.add(username);
        panel.add(password);

        //aggiungo il pannello al frame
        frame.add(panel);

        //opzioni per il frame
        frame.setSize(LARGHEZZA_FINESTRA, ALTEZZA_FINESTRA);
        frame.setResizable(false);

        //se non invoco questa la finestra non viene mostrata
        frame.setVisible(true);
    }
    
}
