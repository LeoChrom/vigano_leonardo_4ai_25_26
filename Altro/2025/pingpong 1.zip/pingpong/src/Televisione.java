
public class Televisione {

    //costanti di classe
    private final int CANALE_MAX = 100;

    // Attributi
    private boolean acceso;
    private int larghezza;
    private int altezza;
    //modificatori di accesso: public / private
    //Information hiding: una classe DOVREBBE avere gli attributi private e i metodi public
    //Incapsulation: le classi DOVREBBERO comunicare con il mondo esterno solo ed
                    //ed esclusivamente attraverso i metodi pubblici
    private int canale;
    private int volume;
    private String marca;

    // principio di overloading
    //all'interno di una classe possono esistere più metodi con lo stesso nome
    //a patto che questi metodi abbiano parametri che differiscono
    //per numero e/o per tipo

    // Costruttore di copia
    public Televisione(Televisione b){
        this.marca = b.marca;
        this.acceso = b.acceso;
        this.larghezza = b.larghezza;
        this.altezza = b.altezza;
        this.canale = b.canale;
        this.volume = b.volume;
    }

    // Costruttore
    public Televisione(String marca, int larghezza, int altezza) {
        this.marca = marca;
        acceso=false;
        this.larghezza = larghezza;
        this.altezza = altezza;
        canale = 1; // Canale iniziale predefinito
        volume = 0; // Volume iniziale predefinito
    }

    public Televisione(String marca, int canale) {
        this.marca = marca;
        acceso=false;
        this.larghezza = 10;
        this.altezza = 10;
        setCanale(canale); // Canale iniziale predefinito
        volume = 0; // Volume iniziale predefinito
    }

    // Metodo per accendere la TV
    public void accendi() {
        acceso = true;
    }

    // Metodo per spegnere la TV
    public void spegni() {
        acceso = false;
    }

    // Metodo per alzare il volume
    public void alzaVolume() {
        volume++;
    }

    // Metodo per abbassare il volume
    public void abbassaVolume() {
        volume--;
    }

    // Metodo per aumentare il canale
    public void incrementaCanale() {
        canale++;
    }

    // Metodo per diminuire il canale
    public void decrementaCanale() {
        setCanale(--canale);
    }

    // Metodo per impostare il canale su un numero specifico

    /**
     * Questo metodo serve per impostare il canale
     * @param canale: il canale da impostare. Il canale deve essere positivo
     * @throws IllegalArgumentException: lancia l'eccezione se il valore del parametro fornito è negativo o nullo
     */
    public void setCanale(int canale) {
        if (canale <= 0 || canale > CANALE_MAX){
            throw new IllegalArgumentException("! - Canale inesistente");
        }
        this.canale = canale;
    }

    /**
     *
     * @return restituisce il canale impostato attualmente
     */
    public int getCanale(){
        return canale;
    }

    @Override
    public String toString() {
        return "Televisione{" +
                "acceso=" + acceso +
                ", larghezza=" + larghezza +
                ", altezza=" + altezza +
                ", canale=" + canale +
                ", volume=" + volume +
                ", marca='" + marca + '\'' +
                '}';
    }


}

