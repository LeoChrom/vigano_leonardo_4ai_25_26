import java.io.IOException;
import java.util.Scanner;

public class Main {
    static private String[] iscritti = new String[10];
    static private int conta = 0;



    public static void main (String[] args) throws IOException {

        Televisione t1 = new Televisione("Samsung", 1 );
        Televisione t2 = new Televisione(t1);
        t2.setCanale(50);

        System.out.println(t1);
        System.out.println(t2);

    }





}