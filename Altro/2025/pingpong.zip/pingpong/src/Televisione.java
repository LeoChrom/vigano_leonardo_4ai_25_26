
public class Televisione {

    // Attributi pubblici
    public boolean acceso;
    public int larghezza;
    public int altezza;
    //modificatori di accesso: public / private
    //Information hiding: una classe DOVREBBE avere gli attributi private e i metodi public
    //Incapsulation: le classi DOVREBBERO comunicare con il mondo esterno solo ed
                    //ed esclusivamente attraverso i metodi pubblici
    private int canale;
    public int volume;
    public String marca;

    // principio di overloading
    //all'interno di una classe possono esistere più metodi con lo stesso nome
    //a patto che questi metodi abbiano parametri che differiscono
    //per numero e/o per tipo

    // Costruttore di default
    public Televisione() {
        this("Samsung", 1, 10, false);
    }

    // Costruttore che prende solo la marca
    public Televisione(String marca) {
        this(marca, 1, 10, false);
    }

    public Televisione(String marca, int canale=10){
        this.marca = marca;
        acceso = false;
        larghezza = 0;
        altezza = 0;
        //this.canale = canale; // Canale iniziale predefinito
        volume = 10; // Volume iniziale predefinito
    }

    private Televisione(String marca, int canale, int volume, boolean acceso){
        this.marca = marca;
        this.acceso = acceso;
        larghezza = 0;
        altezza = 0;
        this.canale = canale; // Canale iniziale predefinito
        this.volume = volume; // Volume iniziale predefinito
    }
    // Metodo per accendere la TV
    public void accendi() {
        acceso = true;
    }

    public void accendi(int h){

    }

    // Metodo per spegnere la TV
    public void spegni() {
        acceso = false;
    }

    // Metodo per alzare il volume
    public void alzaVolume() {
        volume++;
    }

    // Metodo per abbassare il volume
    public void abbassaVolume() {
        volume--;
    }

    // Metodo per aumentare il canale
    public void incrementaCanale() {
        canale++;
    }

    // Metodo per diminuire il canale
    public void decrementaCanale() {
        canale--;
    }

    // Metodo per impostare il canale su un numero specifico
    public void impostaCanale(int canale) {
        if (canale <= 0){
            System.out.println("Il canale non può essere negativo");
        }
        else {
            this.canale = canale;
        }
    }

    public int canaleCorrente(){
        return canale;
    }
}

