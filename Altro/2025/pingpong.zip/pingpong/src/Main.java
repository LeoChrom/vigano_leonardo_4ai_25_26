import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    static private String[] iscritti = new String[10];
    static private int conta = 0;



    public static void main (String[] args) throws IOException {

        Televisione t1 = new Televisione("Samsung", 10);

        int canale = -1;
        try{
            System.out.println("Inserisci il canale da impostare");
            Scanner s = new Scanner(System.in);
            canale = s.nextInt();

        }
        catch (Exception e ){
            System.out.println("Formato del canale non corretto");
        }

        if (canale != -1){
            t1.impostaCanale(canale);
            System.out.println("Il nuovo canale è: " + t1.canaleCorrente());
        }
    }





}