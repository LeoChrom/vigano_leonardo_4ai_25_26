import javax.sound.midi.SysexMessage;
import javax.xml.transform.Source;
import java.sql.SQLOutput;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Griglia g = new Griglia();

        boolean gameover = false;
        int turno = -1;
        Scanner sc = new Scanner(System.in);
        while (!gameover){
            turno = (turno+1)%2;

            //TODO stampa griglia
            char[][] f = g.getGriglia();
            f[2][2] = 'K';

            stampaGriglia(g.getGriglia());

            System.out.println("E' il turno del giocatore " + turno);
            int riga = -1;
            int colonna = -1;

            boolean corretto = false;
            while (!corretto) {
                try {
                    System.out.println("Inserisci la riga");
                    riga = sc.nextInt();
                    System.out.println("Inserisci la colonna");
                    colonna = sc.nextInt();
                    if (turno == 1) {
                        g.inserisciSimbolo(g.SIMBOLO_X, riga, colonna);
                    } else {
                        g.inserisciSimbolo(g.SIMBOLO_O, riga, colonna);
                    }
                    corretto = true;
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }

            char vincita = g.controllaVincita();
            if (vincita == g.SIMBOLO_O) {
                System.out.println("Vince il giocatore 2");
                stampaGriglia(g.getGriglia());
                gameover = true;
            }
            else if (vincita == g.SIMBOLO_X){
                System.out.println("Vince il giocatore 1");
                stampaGriglia(g.getGriglia());
                gameover = true;
            }
            else{
                if (g.stallo()){
                    System.out.println("Situazione di stallo, non vince nessuno");
                    stampaGriglia(g.getGriglia());
                    gameover = true;
                }
            }
        }
    }

    private static void stampaGriglia(char[][] g){
        System.out.print(" ");
        for (int i = 0; i < 3; i++){
            System.out.print(" "+i+" ");
        }
        System.out.println();
        for (int r = 0; r < 3; r++){
            System.out.print(r);
            for (int c = 0; c < 3; c++){
                System.out.print(" "+g[r][c]+"|");
            }
            System.out.println();
            System.out.println(" ──┼──┼──┤");
        }
    }
}