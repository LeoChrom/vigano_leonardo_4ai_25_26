/**
 * Classe che rappresenta la griglia di gioco del Tris (Tic-Tac-Toe).
 *
 * @author Alessio Amato
 * @author Ba
 * @author Gjini
 * @author Tornatola
 * @author Silvestri
 * @author Azzolari
 * @author Ferrari
 * @version 1.0
 */
public class Griglia {
    // Matrice 3x3 che rappresenta la griglia di gioco del tris
    private char[][] griglia;

    // Numero fisso delle caselle per riga/colonna (3x3)
    private final int N_CASELLE = 3;

    // Simbolo che rappresenta una casella vuota
    private final char CASELLA_VUOTA = ' ';

    // Simboli utilizzati dai giocatori
    public final char SIMBOLO_O = 'O';
    public final char SIMBOLO_X = 'X';

    /**
     * Costruttore della classe.
     * Inizializza la matrice e la resetta impostando tutte le caselle vuote.
     */
    public Griglia() {
        griglia = new char[N_CASELLE][N_CASELLE];
        resetGriglia();
    }

    /**
     * Reimposta l'intera griglia mettendo tutte le caselle allo stato vuoto.
     */
    public void resetGriglia() {
        for (int i = 0; i < N_CASELLE; i++) {
            for (int j = 0; j < N_CASELLE; j++) {
                griglia[i][j] = CASELLA_VUOTA;
            }
        }
    }

    /**
     * Inserisce un simbolo ('X' o 'O') nella posizione indicata.
     *
     * @param simbolo simbolo da inserire ('X' o 'O')
     * @param r riga (1–3 per l'utente)
     * @param c colonna (1–3 per l'utente)
     * @throws IllegalArgumentException se la mossa non è valida
     */
    public void inserisciSimbolo(char simbolo, int r, int c) {
        // Conversione da coordinate 1-3 a 0-2
        r = r - 1;
        c = c - 1;

        // Controllo simbolo valido
        if (simbolo != SIMBOLO_X && simbolo != SIMBOLO_O)
            throw new IllegalArgumentException("Simbolo non valido");

        // Controllo coordinate valide
        if (r < 0 || r >= N_CASELLE)
            throw new IllegalArgumentException("Riga fuori dal range");
        if (c < 0 || c >= N_CASELLE)
            throw new IllegalArgumentException("Colonna fuori dal range");

        // Controllo se la casella è libera
        if (griglia[r][c] != CASELLA_VUOTA)
            throw new IllegalArgumentException("Casella già occupata");

        // Inserimento simbolo
        griglia[r][c] = simbolo;
    }

    /**
     * Controlla se c'è un vincitore nel tris.
     *
     * @return 'X' se vince X, 'O' se vince O, ' ' se non c'è un vincitore.
     */
    public char controllaVincita() {

        //TODO - Scritta dal mio cane: non scala

        // --- Controllo righe ---
        for (int i = 0; i < N_CASELLE; i++) {
            if (griglia[i][0] != CASELLA_VUOTA &&
                    griglia[i][0] == griglia[i][1] &&
                    griglia[i][1] == griglia[i][2]) {
                return griglia[i][0];
            }
        }

        // --- Controllo colonne ---
        for (int j = 0; j < N_CASELLE; j++) {
            if (griglia[0][j] != CASELLA_VUOTA &&
                    griglia[0][j] == griglia[1][j] &&
                    griglia[1][j] == griglia[2][j]) {
                return griglia[0][j];
            }
        }

        // --- Controllo diagonale principale ---
        if (griglia[0][0] != CASELLA_VUOTA &&
                griglia[0][0] == griglia[1][1] &&
                griglia[1][1] == griglia[2][2]) {
            return griglia[0][0];
        }

        // --- Controllo diagonale secondaria ---
        if (griglia[0][2] != CASELLA_VUOTA &&
                griglia[0][2] == griglia[1][1] &&
                griglia[1][1] == griglia[2][0]) {
            return griglia[0][2];
        }

        // Nessun vincitore trovato
        return CASELLA_VUOTA;
    }

    /**
     * Controlla se si è verificato uno stallo (griglia piena senza vincitore).
     *
     * @return true se non ci sono caselle vuote, false altrimenti.
     */
    public boolean stallo() {
        for (int r = 0; r < N_CASELLE; r++) {
            for (int c = 0; c < N_CASELLE; c++) {
                if (griglia[r][c] == CASELLA_VUOTA)
                    return false; // C'è ancora spazio, non è stallo
            }
        }
        return true; // Nessuna casella vuota → potenziale stallo
    }

    //restiruisce una copia della griglia da utilizzare per la stampa
    public char[][] getGriglia(){
        char[][] copia = new char[N_CASELLE][N_CASELLE];
        for (int r = 0; r < N_CASELLE; r++) {
            for (int c = 0; c < N_CASELLE; c++) {
                copia[r][c] = griglia[r][c];
            }
        }
        return copia;
    }

}