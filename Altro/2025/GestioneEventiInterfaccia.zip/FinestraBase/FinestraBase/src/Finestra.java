import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Finestra implements ActionListener{

    private final int LARGHEZZA_FINESTRA = 400;
    private final int ALTEZZA_FINESTRA = 400;

    private JFrame frame;
    private JPanel panel;
    private JTextField usernameTXF;
    private JTextField passwordTXF;
    private JButton clearBTN;
    private JButton loginBTN;

    public Finestra() {

        //creo il frame
        frame = new JFrame("Finestra di login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //creo il pannello che conterrà i componenti grafici
        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        //creo i componenti con le dimensioni volute
        usernameTXF = new JTextField();
        usernameTXF.setMaximumSize(new Dimension(LARGHEZZA_FINESTRA - 40, 20));
        passwordTXF = new JTextField();
        passwordTXF.setMaximumSize(new Dimension(LARGHEZZA_FINESTRA - 40, 20));

        //creo un bottone
        loginBTN = new JButton("Esegui login");
        loginBTN.addActionListener(this);

        //creo bottone pulizia
        clearBTN = new JButton("Pulisci form");
        clearBTN.addActionListener(this);

        //aggiungo i componenti al pannello
        panel.add(usernameTXF);
        panel.add(passwordTXF);
        panel.add(loginBTN);
        panel.add(clearBTN);

        //aggiungo il pannello al frame
        frame.add(panel);

        //opzioni per il frame
        frame.setSize(LARGHEZZA_FINESTRA, ALTEZZA_FINESTRA);
        frame.setResizable(false);

        //se non invoco questa la finestra non viene mostrata
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginBTN){

            //recupero dalle textbox i valori inseriti dall'utente
            String username = usernameTXF.getText();
            String password = passwordTXF.getText();
            //controllo i dati
            //eseguo la login
            if (username.equals("admin") && password.equals("admin")){
                JOptionPane.showMessageDialog(null, "Login effettuata con successo");
            }
            else {
                JOptionPane.showMessageDialog(null, "Login errata");
            }

        }
        else if (e.getSource() == clearBTN){
            usernameTXF.setText("");
            passwordTXF.setText("");
        }
    }
}
