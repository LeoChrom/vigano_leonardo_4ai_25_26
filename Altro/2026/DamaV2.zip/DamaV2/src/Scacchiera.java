public class Scacchiera {

    public final static int N_CASELLE = 8;

    private Pedina[][] scacchiera;

    public Scacchiera() throws DamaException {
        scacchiera = new Pedina[N_CASELLE][N_CASELLE];
        //creo le pedine bianche (righe dalla 1 alla 3)
        for (int r = 0; r < 3; r++){
            for (int c = 0; c < N_CASELLE; c++){
                if (((r+1)+(c+1))%2 != 0)
                    scacchiera[r][c] = new Pedina(r+1, c+1, Pedina.Colore.NERO);
            }
        }
        //creo le pedine nere (righe dalla 1 alla 3)
        for (int r = 5; r < N_CASELLE; r++){
            for (int c = 0; c < N_CASELLE; c++){
                if (((r+1)+(c+1))%2 != 0)
                    scacchiera[r][c] = new Pedina(r+1, c+1, Pedina.Colore.BIANCO);
            }
        }
    }

    public Scacchiera(Scacchiera altra) {
        scacchiera = new Pedina[N_CASELLE][N_CASELLE];
        for (int r = 0; r < N_CASELLE; r++) {
            for (int c = 0; c < N_CASELLE; c++) {
                scacchiera[r][c] = altra.scacchiera[r][c];
            }
        }
    }

    public Scacchiera getScacchiera() {
        return new Scacchiera(this);
    }
}

