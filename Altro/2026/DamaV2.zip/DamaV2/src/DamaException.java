public class DamaException extends Exception {
    DamaException(String messaggio){
        super(messaggio);
    }
}
