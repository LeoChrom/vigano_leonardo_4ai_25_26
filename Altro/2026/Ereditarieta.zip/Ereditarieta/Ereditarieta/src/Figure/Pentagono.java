package Figure;

public class Pentagono extends FiguraGeometrica {

    public Pentagono(float lunghezzaLato){
        super(5, lunghezzaLato);
    }

}

