package Figure;

public class Quadrato extends FiguraGeometrica {

    public Quadrato(float lunghezzaLato){
        super(4, lunghezzaLato);
    }

}

