package io.github.some_example_name;

public enum StatoLamp {
    SPENTA, ACCESA, ROTTA
}
