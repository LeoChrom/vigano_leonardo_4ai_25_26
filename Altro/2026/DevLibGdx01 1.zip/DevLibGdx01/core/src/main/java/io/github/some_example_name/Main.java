package io.github.some_example_name;


import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.files.FileHandle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/*   __  __       _
    |  \/  | __ _(_)_ __
    | |\/| |/ _` | | '_ \
    | |  | | (_| | | | | |
    |_|  |_|\__,_|_|_| |_|  Entry point dell'applicazione.
*/
public class Main extends ApplicationAdapter {
    private Random r;
    private List<Lampadina> archivio = new ArrayList<Lampadina>();

    private SpriteBatch batch;
    private Texture image;
    private TextureRegion region;
    private Sprite sprite;
    private int mouseX;
    private BitmapFont font;
    private String text;

    private Texture lamp;
    private TextureRegion lampSpenta,lampAccesa, lampRotta;

    @Override
    public void create() {
        r = new Random();
        batch = new SpriteBatch();
        image = new Texture("libgdx.png");
        region = new TextureRegion(image, 20, 20, 50, 50);
        FileHandle file = new FileHandle("prova.txt");
        text = file.readString();
        font = new BitmapFont();


        lamp = new Texture("lampadina.png");
        lampSpenta = new TextureRegion(lamp, 0, 0, 40, 50);
        lampAccesa = new TextureRegion(lamp, 40, 0, 40, 50);
        lampRotta = new TextureRegion(lamp, 80, 0, 40, 50);

        for(int i=0; i<2000; i++){
            Lampadina l1 = new Lampadina();
            l1.posiziona(r.nextInt(300, 600), r.nextInt(300, 450));
            archivio.add(l1);
        }
    }

    @Override
    public void render() {
        // Update application
        for (Lampadina l : archivio) {
            l.posiziona(l.getX() + r.nextInt(-1,2), l.getY() + r.nextInt(-1, 2));
        }
        mouseX = Gdx.input.getX();
        boolean leftPressed = Gdx.input.isButtonPressed(Input.Buttons.LEFT);
        boolean rightPressed = Gdx.input.isButtonPressed(Input.Buttons.RIGHT);
        if (Gdx.input.isKeyPressed(Keys.A) == true) {
            for (Lampadina l : archivio) {
                l.accendi();
            }
        }
        if (Gdx.input.isKeyPressed(Keys.S) == true) {
            for (Lampadina l : archivio) {
                l.spegni();
            }
        }
        if (Gdx.input.isKeyPressed(Keys.C) == true) {
            for(int i=0; i<10; i++){
                Lampadina l1 = new Lampadina();
                l1.posiziona(r.nextInt(5, 700), r.nextInt(400, 520));
                archivio.add(l1);
            }
        }

        // Render
        ScreenUtils.clear(Color.BLACK);
        batch.begin();
        disegnaLampadine(archivio);
        // Informazioni sulle lampadine

        font.draw(batch, "Ciao", 10, 500);
        font.draw(batch, String.valueOf(mouseX), 10, 520);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        image.dispose();
    }

    public void disegnaLampadine(List<Lampadina> a){
        for (Lampadina l : a) {
            switch(l.getStato()){
                case SPENTA: batch.draw(lampSpenta, l.getX(), l.getY()); break;
                case ACCESA: batch.draw(lampAccesa, l.getX(), l.getY()); break;
                case ROTTA: batch.draw(lampRotta, l.getX(), l.getY()); break;
            }
        }

        font.draw(batch, "Lampadine in archivio : " + String.valueOf(a.size()), 10, 590);
    }


}






