public class Torre extends Pedina{
    @Override
    public void muovi() {
        System.out.println("Muovi di Torre");
    }

    public void arrocco(){
        System.out.println("Arrocco di torre");
    }
}
