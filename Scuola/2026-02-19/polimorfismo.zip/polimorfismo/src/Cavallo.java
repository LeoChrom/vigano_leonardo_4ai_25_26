public class Cavallo extends  Pedina{

    @Override
    public void muovi() {
        System.out.println("Muovi di Cavallo");
    }
}
