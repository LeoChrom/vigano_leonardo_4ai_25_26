public class Pedina {
    Pedina(){}

    public void muovi(){
        System.out.println("Muovi di Pedina");
    }
}
